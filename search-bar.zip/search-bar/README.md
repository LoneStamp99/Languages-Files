# Search Bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aixoxa/pen/dyXbPEG](https://codepen.io/Aixoxa/pen/dyXbPEG).

