# 🔥 Magic Motion Button
## [Watch it on youtube](https://youtu.be/xjCUw2EHSgQ)
### 🔥 Magic Motion Button

- Magic Motion Button Using HTML & CSS.
- With hover effect animation.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
