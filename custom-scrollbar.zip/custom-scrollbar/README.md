# Custom Scrollbar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aixoxa/pen/JjXvNLZ](https://codepen.io/Aixoxa/pen/JjXvNLZ).

