# Lighting effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aixoxa/pen/LYGmGVv](https://codepen.io/Aixoxa/pen/LYGmGVv).

