# Image slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aixoxa/pen/KKVeBed](https://codepen.io/Aixoxa/pen/KKVeBed).

