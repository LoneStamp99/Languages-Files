# image hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/Aixoxa/pen/mdPxKjd](https://codepen.io/Aixoxa/pen/mdPxKjd).

