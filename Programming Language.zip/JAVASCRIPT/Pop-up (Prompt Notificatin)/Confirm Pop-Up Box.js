if(confirm("Hey are you okay")) {
    alert("You pressed OK. Thank you.");
} else {
alert("You pressed Cancel.");
}