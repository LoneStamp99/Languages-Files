var firstName = prompt("What is your first name?");

if(firstName == "" || firstName == null) {
    alert("You did not enter your name.");
} else {
    alert("Hi" + firstName + ", always remember you're special.");
}